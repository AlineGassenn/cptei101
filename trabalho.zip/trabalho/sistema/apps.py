from django.apps import AppConfig


class ImoveisConfig(AppConfig):
    name = 'sistema'
    verbose_name = 'Sistema My House'
